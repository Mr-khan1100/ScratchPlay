import { useState, useEffect, useRef, useCallback } from 'react';

export default function useSprites() {
  const [sprites, setSprites] = useState([
    { 
      id: 1, 
      name: 'Cat', 
      x: 50, 
      y: 50, 
      rotation: 0,
      currentAction: null,
      scripts: [],
      isDragging: false,
      dragOffset: { x: 0, y: 0 }
    }
  ]);

  const [customBlocks, setCustomBlocks] = useState({
    motion: [
      { id: 1, type: 'move', label: 'Move 10 steps', value: 10, category: 'motion' },
      { id: 2, type: 'turn', label: 'Turn 15 degrees', value: 15, category: 'motion' },
      { id: 3, type: 'goto', label: 'Go to X:10 Y:10',x:10, y:10, category: 'motion' },
      { id: 4, type: 'repeat', label: 'Repeat 2 times', count:2, category: 'motion' }
    ],
    looks: [
      { id: 5, type: 'say', label: 'Say Hello for 2 seconds', text: 'Hello!', duration: 2, category: 'looks' },
      { id: 6, type: 'think', label: 'Think Hmm... for 2 seconds', text: 'Hmm...', duration: 2, category: 'looks' }
    ]
  });

  const nextBlockId = useRef(7);
  const nextId = useRef(2);
  const [currentSpriteId, setCurrentSpriteId] = useState(1);
  const [isPlaying, setIsPlaying] = useState(false);
  const collisionPairs = useRef({});
  const actionTimeouts = useRef({});

  const addCustomBlock = (category, block) => {
    const newBlock = {
      ...block,
      id: nextBlockId.current++,
      category
    };
    
    setCustomBlocks(prev => ({
      ...prev,
      [category]: [...prev[category], newBlock]
    }));
  };

  const updateCustomBlock = (id, updates) => {
    setCustomBlocks(prev => {
      const updated = {...prev};
      for (const category of ['motion', 'looks']) {
        const index = updated[category].findIndex(b => b.id === id);
        if (index !== -1) {
          updated[category][index] = {...updated[category][index], ...updates};
          break;
        }
      }
      return updated;
    });
  };

  const removeCustomBlock = (id) => {
    setCustomBlocks(prev => {
      const updated = {...prev};
      for (const category of ['motion', 'looks']) {
        updated[category] = updated[category].filter(b => b.id !== id);
      }
      return updated;
    });
  };

  const addSprite = useCallback(() => {
    const newId = nextId.current++;
    setSprites(prev => [
      ...prev,
      {
        id: newId,
        name: `Sprite ${newId}`,
        x: Math.random() * 200,
        y: Math.random() * 200,
        rotation: 0,
        currentAction: null,
        scripts: [],
        isDragging: false,
        dragOffset: { x: 0, y: 0 }
      }
    ]);
  }, []);

  const removeSprite = useCallback((id) => {
    if (sprites.length <= 1) {
      alert("You need at least one sprite!");
      return;
    }
    
    setSprites(prev => prev.filter(sprite => sprite.id !== id));
    
    // If we're removing the currently selected sprite, select another one
    if (id === currentSpriteId) {
      const remainingSprites = sprites.filter(sprite => sprite.id !== id);
      if (remainingSprites.length > 0) {
        setCurrentSpriteId(remainingSprites[0].id);
      }
    }
  }, [sprites, currentSpriteId]);

  const updateSprite = useCallback((id, updates) => {
    setSprites(prev => prev.map(sprite => 
      sprite.id === id ? { ...sprite, ...updates } : sprite
    ));
  }, []);

  const clearAllTimeouts = useCallback(() => {
    Object.values(actionTimeouts.current).forEach(timeout => {
      clearTimeout(timeout);
    });
    actionTimeouts.current = {};
  }, []);

  const executeAnimation = useCallback(() => {
    // Clear any existing timeouts
    console.log("Executing animation...");
    clearAllTimeouts();
    setIsPlaying(true);
    
    // Create a new array of updated sprites
    setSprites(prevSprites => {
      const updatedSprites = prevSprites.map(sprite => {
        let newX = sprite.x;
        let newY = sprite.y;
        let newRotation = sprite.rotation;
        let currentAction = null;

        let repeatStartIndex = -1;
      let repeatCount = 1;
      let repeatBlocks = [];

       for (let i = 0; i < sprite.scripts.length; i++) {
        const script = sprite.scripts[i];
        
        // If we find a repeat block, capture the repeat parameters
        if (script.type === 'repeat') {
          repeatStartIndex = i;
          repeatCount = script.count;
          break;
        }
      }
      
      // If we have a repeat block
      if (repeatStartIndex !== -1) {
        // Get the blocks to repeat (all before the repeat block)
        repeatBlocks = sprite.scripts.slice(0, repeatStartIndex);
        
        // Execute the repeat block multiple times
        for (let r = 0; r < repeatCount; r++) {
          for (const script of repeatBlocks) {
            executeScript(script);
          }
        }
      } else {
        // No repeat block, execute all scripts normally
        for (const script of sprite.scripts) {
          executeScript(script);
        }
      }
      
        
        // Process all scripts for this sprite
        function executeScript(script) {
          if (script.category === 'motion') {
            switch (script.type) {
              case 'move':
                newX += script.value * Math.cos(newRotation * Math.PI / 180);
                newY += script.value * Math.sin(newRotation * Math.PI / 180);
                break;
              case 'turn':
                newRotation += script.value;
                break;
              case 'goto':
                if (script.x !== undefined) newX = script.x;
                if (script.y !== undefined) newY = script.y;
                break;
            }
          } else if (script.category === 'looks') {
            if (script.type === 'say' || script.type === 'think') {
              currentAction = {
                type: script.type,
                text: script.text,
                duration: script.duration
              };
            }
          }
        };
        
        return {
          ...sprite,
          x: newX,
          y: newY,
          rotation: newRotation,
          currentAction
        };
      });
      
      return updatedSprites;
    });
    
    // Set timeouts to clear actions after duration
    sprites.forEach(sprite => {
      sprite.scripts.forEach(script => {
        if (script.category === 'looks' && (script.type === 'say' || script.type === 'think')) {
          const timeoutId = setTimeout(() => {
            updateSprite(sprite.id, { currentAction: null });
          }, script.duration * 1000);
          
          actionTimeouts.current[`${sprite.id}-${Date.now()}`] = timeoutId;
        }
      });
    });
    
    // Check for collisions
    const currentCollisions = {};
    for (let i = 0; i < sprites.length; i++) {
      for (let j = i + 1; j < sprites.length; j++) {
        const a = sprites[i];
        const b = sprites[j];
        const pairKey = `${Math.min(a.id, b.id)}-${Math.max(a.id, b.id)}`;
        const distance = Math.sqrt((a.x - b.x) ** 2 + (a.y - b.y) ** 2);
        
        if (distance < 50) {
          currentCollisions[pairKey] = true;
          if (!collisionPairs.current[pairKey]) {
            // Swap animations
            updateSprite(a.id, { scripts: [...b.scripts] });
            updateSprite(b.id, { scripts: [...a.scripts] });
          }
        }
      }
    }
    
    collisionPairs.current = currentCollisions;
    setTimeout(() => setIsPlaying(false), 1000);
  }, [sprites, updateSprite, clearAllTimeouts]);

 
  useEffect(() => {
    return () => clearAllTimeouts();
  }, [clearAllTimeouts]);

  return {
    sprites,
    currentSpriteId,
    setCurrentSpriteId,
    removeSprite,
    addSprite,
    updateSprite,
    executeAnimation,
    isPlaying,
    customBlocks,
    addCustomBlock,
    updateCustomBlock,
    removeCustomBlock
  };
}